function varargout = GUINuevo(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUINuevo_OpeningFcn, ...
                   'gui_OutputFcn',  @GUINuevo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

global imagen;
global imagen2;
global imagen3;
global numerosTotales;
global media;
global mediana;
global moda;
global N;


N= 100;
imagen = randi(3,1,N);
imagen2=randi(3,1,N);
imagen3=randi(3,1,N);
numerosTotales=[imagen imagen2 imagen3];


hist(numerosTotales,[1 2 3])



media = mean(numerosTotales);
mediana = median(numerosTotales)
moda= mode(numerosTotales)

varianza = var(numerosTotales)
desviacion = std(numerosTotales)

%varianzaN = sum((numerosTotales-media).^2)/(N)
%sum((numerosTotales-3.5).^2)/(N)


function GUINuevo_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;
guidata(hObject, handles);




function varargout = GUINuevo_OutputFcn(hObject, eventdata, handles) 

varargout{1} = handles.output;


function Star_Callback(hObject, eventdata, handles)

imagen = randi(3,1);
imagen2=randi(3,1);
imagen3=randi(3,1);

switch imagen 
    case 1        
    im = imread('hongo.png');
    axes(handles.Imagen1);
    imshow(im);
    set(handles.Imagen2,'UserData', im);
    case 2
    im = imread('flor.png');
    axes(handles.Imagen1);
    imshow(im);
    set(handles.Imagen2,'UserData', im);
    case 3
    im = imread('estrella.jpg');
    axes(handles.Imagen1);
    imshow(im);
    set(handles.Imagen1,'UserData', im);
end
 switch imagen2 
    case 1        
    im = imread('hongo.png');
    axes(handles.Imagen2);
    imshow(im);
    set(handles.Imagen2,'UserData', im);
    case 2
    im = imread('flor.png');
    axes(handles.Imagen2);
    imshow(im);
    set(handles.Imagen2,'UserData', im);
    case 3
    im = imread('estrella.jpg');
    axes(handles.Imagen2);
    imshow(im);
    set(handles.Imagen2,'UserData', im);
 end

switch imagen3 
    case 1        
    im = imread('hongo.png');
    axes(handles.Imagen3);
    imshow(im);
    set(handles.Imagen3,'UserData', im);
    case 2
    im = imread('flor.png');
    axes(handles.Imagen3);
    imshow(im);
    set(handles.Imagen3,'UserData', im);
    case 3
    im = imread('estrella.jpg');
    axes(handles.Imagen3);
    imshow(im);
    set(handles.Imagen3,'UserData', im);
end


   
  
