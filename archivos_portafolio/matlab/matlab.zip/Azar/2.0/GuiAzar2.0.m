function varargout = GuiAzar(varargin)

%use guide to inicialice the GUI

% GUIAZAR MATLAB code for GuiAzar.fig
%      GUIAZAR, by itself, creates a new GUIAZAR or raises the existing
%      singleton*.
%
%      H = GUIAZAR returns the handle to a new GUIAZAR or the handle to
%      the existing singleton*.
%
%      GUIAZAR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUIAZAR.M with the given input arguments.
%
%      GUIAZAR('Property','Value',...) creates a new GUIAZAR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GuiAzar_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GuiAzar_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GuiAzar

% Last Modified by GUIDE v2.5 09-Feb-2017 12:25:04

% Begin initialization code - DO NOT EDIT
N= 20;
imagen=randi(3,1,N);
imagen2=randi(3,1,N);
imagen3=randi(3,1,N);
numerosTotales=[imagen imagen2 imagen3];

hist(numerosTotales,[1 2 3]);

media = mean(numerosTotales);
mediana = median(numerosTotales)
moda= mode(numerosTotales)

varianza = var(numerosTotales)
desviacion = std(numerosTotales)

varianzaN = sum((numerosTotales-media).^2)/(N)
sum((numerosTotales-3.5).^2)/(N)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GuiAzar_OpeningFcn, ...
                   'gui_OutputFcn',  @GuiAzar_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GuiAzar is made visible.
function GuiAzar_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GuiAzar (see VARARGIN)

% Choose default command line output for GuiAzar
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GuiAzar wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GuiAzar_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Star.
function Star_Callback(hObject, eventdata, handles)
% hObject    handle to Star (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(imagen == 1)
im = imread('flor.png'); %solo queda declarada en esta funcion, no se accede desde la otra
axes(handles.Simbolo1);
imshow(im);
set(handles.Simbolo1,'UserData', im); % almacena en, 'UserData', que cosa;
% im = get(handles.simbolo1,'UserData'); para leerla desde alguna otra
% funci�n
else
im = imread('hongo.png'); %solo queda declarada en esta funcion, no se accede desde la otra
axes(handles.Simbolo1);
imshow(im);
set(handles.Simbolo1,'UserData', im);
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
im2 = imread('hongo.png'); %solo queda declarada en esta funcion, no se accede desde la otra
axes(handles.Simbolo2);
imshow(im2);
set(handles.Simbolo2,'UserData2', im2);


% --- Executes on button press in HistogramaButton.
function HistogramaButton_Callback(hObject, eventdata, handles)
% hObject    handle to HistogramaButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hist(numerosTotales,[1 2 3]);
axes(handles.Histograma);
set(handles.Histograma,'UserData3');

