
N= 20;
imagen=randi(3,1,N);
imagen2=randi(3,1,N);
imagen3=randi(3,1,N);
numerosTotales=[imagen imagen2 imagen3];

hist(numerosTotales,[1 2 3])

media = mean(numerosTotales)
mediana = median(numerosTotales)
moda= mode(numerosTotales)

varianza = var(numerosTotales)
desviacion = std(numerosTotales)

varianzaN = sum((numerosTotales-media).^2)/(N)
sum((numerosTotales-3.5).^2)/(N)