function varargout = GuiAzar(varargin)

global imagen;
global imagen2;
global imagen3;
global numerosTotales;
global media;
global mediana;
global moda;
global N;


N= 10;
imagen = randi(3,1,N);
imagen2=randi(3,1,N);
imagen3=randi(3,1,N);
numerosTotales=[imagen imagen2 imagen3];
hist(numerosTotales,[1 2 3]);


media = mean(numerosTotales);
mediana = median(numerosTotales)
moda= mode(numerosTotales)

varianza = var(numerosTotales)
desviacion = std(numerosTotales)

%varianzaN = sum((numerosTotales-media).^2)/(N)
%sum((numerosTotales-3.5).^2)/(N)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GuiAzar_OpeningFcn, ...
                   'gui_OutputFcn',  @GuiAzar_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function GuiAzar_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GuiAzar wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GuiAzar_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Star.
function Star_Callback(hObject, eventdata, handles)
im = imread('hongo.png'); %solo queda declarada en esta funcion, no se accede desde la otra
axes(handles.Simbolo1);
imshow(im);
set(handles.Simbolo1,'UserData', im); % almacena en, 'UserData', que cosa;



function Star2_Callback(hObject, eventdata, handles)
im2 = imread('pokeball.png'); %solo queda declarada en esta funcion, no se accede desde la otra
axes(handles.Simbolo2);
imshow(im2);
set(handles.Simbolo2,'UserData', im2);



function HistogramaButton_Callback(hObject, eventdata, handles)


set(handles.Histograma,'UserData',hist(numerosTotales,[1 2 3]));



function edit1_Callback(hObject, eventdata, handles)

global N ;
N = str2double(get(hObject,'String'));




% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end