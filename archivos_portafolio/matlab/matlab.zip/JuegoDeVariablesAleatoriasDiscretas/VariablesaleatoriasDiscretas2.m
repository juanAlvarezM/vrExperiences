valoresTomados = [1 1 1 1 1 1 1 1 1 1 1 1 1 2 2 2 2 2 2 2 3 3 3 3 3 3 3 4 4 4 4 4 4 4 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 6 6 6 6 6 6 6 6 6 6 6 6 6 6 7 7 7 7 7 7 7 7 7 7 7 7 7 7 8 8 8 8 8 9 9 9 9 9 9 9 9 9 9 9 9 9] 

%N=1
im = imread('ruleta.png');
   % imshow(im);
   
a=figure(1);
t=pi/4;
b=annotation(a,'arrow','HeadWidth',30,'HeadLength',50,'x',[0.5 0.5+0.3*cos(t)],'y',[0.5 0.5+0.3*sin(t)]); %crea un vector de un tama�o determinado que aparece en cada pi/4 = 45�  
bb=linspace(0,2*pi,9); % regresa un vector entre a y 9  en 360�
%T=randi([100 200]); % Especifica un rango de valores entre el minimo y el maximo 
%T=randi(9,1,N)
T = 0;
lanzamientosTotales =0;
global valoresTotales;

for  i = 1:100    
    T2 = randi (100,1);
    if T2 <= 13
        T = 1 
    elseif T2 <= 20
            T = 2 
        elseif T2 <= 27
            T = 3
            elseif T2 <= 34 
                T = 4
                elseif T2 <= 54
                    T = 5 
                    elseif T2 <= 68
                        T = 6
                        elseif T2 <= 82
                            T = 7 
                            elseif T2 <= 87
                                T = 8
                                elseif T2 <= 100
                                    T = 9
                               
    end
    valoresTotales = [valoresTotales T]
        
end
   media = mean(valoresTotales)
   varianza = var(valoresTotales)
   moda= mode(valoresTotales)


hist(valoresTotales, [1 2 3 4 5 6 7 8 9], figure(2));
set(get(gca,'child'),'FaceColor','blue','EdgeColor','r');
hist(valoresTomados, [1 2 3 4 5 6 7 8 9], figure(3));
set(get(gca,'child'),'FaceColor','red','EdgeColor','c');
%numerosTotales=[T];
%hist(T, [1 2 3 4 5 6 7 8 9], figure(2));
i=1;
while T~=0 %mientras que el valor random no sea igual a 0 
    t=bb(i);
    set(b,'x',[0.5 0.5+0.3*cos(t)],'y',[0.5 0.5+0.3*sin(t)])
    if i==length(bb)
        i=1;
    else
        i=i+1;
    end
    T=T-1;
    pause(0.5)
end
disp(i)